#!/usr/bin/env bash
set -e

echo "========== jenkins-agent.sh starting =========="
echo "IMAGE_VERSION=1.7"
echo "JENKINS_AGENT_WORKDIR=${JENKINS_AGENT_WORKDIR:-unset}"
echo "------------------------------------------------"
echo "Key Jenkins-related env vars:"
echo "  JENKINS_URL       = '${JENKINS_URL:-<empty>}'"
echo "  JENKINS_SECRET    = '${JENKINS_SECRET:-<empty>}'"
echo "  JENKINS_AGENT_NAME= '${JENKINS_AGENT_NAME:-<empty>}'"
echo "------------------------------------------------"
echo "Full environment:"
env | sort
echo "------------------------------------------------"

if [ -z "${JENKINS_URL:-}" ] || [ -z "${JENKINS_SECRET:-}" ] || [ -z "${JENKINS_AGENT_NAME:-}" ]; then
  echo "ERROR: Missing one of JENKINS_URL, JENKINS_SECRET, JENKINS_AGENT_NAME – cannot start agent."
  # Sleep a bit so logs are visible before Fargate kills the task
  sleep 60
  exit 1
fi

echo "All required Jenkins variables are present. Downloading agent.jar from: ${JENKINS_URL}"

mkdir -p /usr/share/jenkins

curl -fsSL "${JENKINS_URL%/}/jnlpJars/agent.jar" -o /usr/share/jenkins/agent.jar

echo "Downloaded agent.jar, starting JNLP agent..."
echo "java -jar /usr/share/jenkins/agent.jar -jnlpUrl ${JENKINS_URL%/}/computer/${JENKINS_AGENT_NAME}/jenkins-agent.jnlp -workDir ${JENKINS_AGENT_WORKDIR}"

exec java -jar /usr/share/jenkins/agent.jar \
  -jnlpUrl "${JENKINS_URL%/}/computer/${JENKINS_AGENT_NAME}/jenkins-agent.jnlp" \
  -secret "${JENKINS_SECRET}" \
  -workDir "${JENKINS_AGENT_WORKDIR}"
